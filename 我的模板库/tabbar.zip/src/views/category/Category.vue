<template>
  <div class="category">
    <h1>This is an category page</h1>
  </div>
</template>
