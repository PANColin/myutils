<template>
  <div class="cart">
    <h1>This is an cart page</h1>
  </div>
</template>
