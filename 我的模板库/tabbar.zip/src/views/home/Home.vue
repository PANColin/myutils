<template>
  <div class="home">
    <h1>This is an home page</h1>
  </div>
</template>

<script>
export default {
  name: "Home",
  components: {},
  methods: {
    init() {
      this.$axios
        .get("/simpleWeather/query", {
          params: { city: "郑州", key: "8e77a06e7ec12ebebfe752de412ddb30" },
        })
        .then((res) => {
          console.log(res);
        });
      this.$axios
        .get("/constellation/getAll", {
          params: { consName:"摩羯座",type:"today",key: "a3c58a07ff8c876634bfd9a3a0fc9a61" },
        })
        .then((res) => {
          console.log(res);
        });
      this.$axios
        .get("/fapig/sudoku/generate", {
          params: { difficulty:"normal",key: "4c04b73a3fb58687a90b93f25ff30d1e" },
        })
        .then((res) => {
          console.log(res);
        });
      this.$axios
        .get("/qqevaluate/qq", {
          params: { qq:"2453608381",key: "4a7c2335a18b68f326e1a4a01afbc3d5" },
        })
        .then((res) => {
          console.log(res);
        });
    },
  },
  created() {
    this.init();
  },
};
</script>
